// Yay, this is awesome.

window.open("firessh.html", "FireSSH", "width=800,height=600,alwaysRaised=yes");
window.close();
