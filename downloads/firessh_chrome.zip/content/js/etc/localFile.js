var localFile = {
  init : function(path) {
    // left here as shim for paramikojs code
    // will chrome ever support local files?? the world may never know...
    return null;
  }
}
