# [Fancy Settings 1.2](https://github.com/frankkohlhepp/fancy-settings)
*Create fancy, chrome-look-alike settings for your Chrome or Safari extension in minutes!*

### Howto
Welcome to Fancy Settings! Are you ready for tabs, groups, search, good style?  
Let's get started, it only takes a few minutes...

[Getting started](https://github.com/frankkohlhepp/fancy-settings/wiki)  
[View Sample](http://frankkohlhepp.github.com/fancy-settings/)

### License
Fancy Settings is licensed under the **LGPL 2.1**.  
For details see *LICENSE.txt*
